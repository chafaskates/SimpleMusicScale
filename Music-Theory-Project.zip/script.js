let c3, d3, e3, f3, g3, a4, b4, c4, d4, e4, f4;
let img;
let noStroke;

function preload(){
  console.log("in preload")
  c3 = loadSound ("c3.mp3")
  d3 = loadSound ("d3.mp3")
  e3 = loadSound ("e3.mp3")
  f3 = loadSound ("f3.mp3")
  g3 = loadSound ("g3.mp3")
  a4 = loadSound ("a4.mp3")
  b4 = loadSound ("b4.mp3")
  c4 = loadSound ("c4.mp3")
  d4 = loadSound ("d4.mp3")
  e4 = loadSound ("e4.mp3")
  f4 = loadSound ("f4.mp3")
  img = loadImage('trebleclef.png');
  console.log("leaving preload")
}


function setup(){
//Creates canvas 
  createCanvas(600, 900);
  colorMode(RGB, 100);
  this.col = color(0);
  this.c = color(0);
  this.co = color (0);
  this.col2 = color(0);
  this.c2 = color (0);
  this.co2 = color (0);
  this.col3 = color(0);
  this.c3 = color (0);
  this.co3 = color (0);
  this.col4 = color(0);
  this.c4 = color (0);
  
}


function draw(){
background(245);
//strokeweight(4);
notes();
text("Treble Clef Staff", 210, 20);

image(img, 20, 20, 120, 230)
// makes the line black 
// treble line staff
line(30, 195 , 30 , 35)// treble line
line(500, 195, 500, 35)// last line
line( 30,35, 500, 35);// 1st line
line( 30,75, 500, 75); // 2nd  line 
line( 30,115, 500, 115); // 3rd line
line( 30,155, 500, 155); // 4th line 
line( 30,195, 500, 195); // 5th line 
//Text
// text("Treble Clef Staff", 210, 20);
//The Notes

}


function notes(){
  //stroke(r, g, b);
  
  fill(this.col);

  ellipse(163, 225, 30, 20)
  line(30,225,193,225 )

  fill(this.c);
  ellipse(195,210, 30, 20);// (D)
  fill(this.co);
  ellipse(225,195, 30, 20);//(E)
  fill(this.col2);
  ellipse(258,175, 30, 20);//(F
  fill(this.c2);
  ellipse(295,155, 30, 20);//(G)
  fill(this.co2);
  ellipse(325,135, 30, 20);//(A)
   fill(this.col3);
  ellipse(355,115, 30, 20);//(B)
   fill(this.c3);
  ellipse(385,95, 30, 20);//(C)
   fill(this.co3);
  ellipse(415,75, 30, 20);//(D)
  fill(this.col4);
  ellipse(445,55, 30, 20);//(E)
  fill(this.c4);
  ellipse(475,35, 30, 20);//(F)
  
}

function mousePressed(){

    let a = dist(mouseX, mouseY, 163, 225);
    if(a < 12){
      
      console.log("before play")
      c3.play();
      console.log("after play")
      this.col = color(255, 0, 0);
    }
    else{
      this.col = color(0)
    }
   
    let z = dist(mouseX, mouseY, 195, 210)
    if(z < 12 ){
      console.log("before play")
      d3.play();
      console.log("after play")
       this.c = color (255, 2, 2);
    }
    else{
      this.c = color(0)
    } 
   
    let c = dist(mouseX, mouseY, 225, 195)
    if(c < 12){
      console.log("before play")
      e3.play();
      console.log("after play")
      this.co= color (162, 42, 2);
    }
    else{
      this.co = color(0)
    }

    let d = dist(mouseX, mouseY, 258, 175)
    if(d < 12){
      console.log("before play")
      f3.play();
      console.log("after play")
      this.col2 = color (162, 82, 2);
    }
    else{
      this.col2 = color(0)
    }

    let e = dist(mouseX, mouseY, 295, 155)
    if(e < 12){
      console.log("before play")
      g3.play();
      console.log("after play")
     this.c2 = color (255, 128, 0);
    }
    else{
      this.c2 = color(0)
    }

    let f = dist(mouseX, mouseY, 325, 135)
    if(f < 12){
      console.log("before play")
      a4.play();
      console.log("after play")
      this.co2 = color (42, 162, 2);
    }
    else{
      this.co2 = color(0)
    }

     let l = dist(mouseX, mouseY, 355, 115)
    if(l < 12){
      console.log("before play")
      b4.play();
      console.log("after play")
      this.col3 = color (2, 162, 42);
    }
    else{
      this.col3 = color(0)
      }
   
let m = dist(mouseX, mouseY, 385, 95)
    if(m < 12){
      console.log("before play")
      c4.play();
      console.log("after play")
      this.c3 = color (2, 52, 162);
    }
    else{
      this.c3 = color(0)
  }
  
  let n = dist(mouseX, mouseY, 415, 75)
    if(n < 12){
      console.log("before play")
      d4.play();
      console.log("after play")
      this.co3 = color (2, 32, 162);
    }
    else{
      this.co3 = color(0)
    }

    let o = dist(mouseX, mouseY, 445, 55)
    if(o < 12){
      console.log("before play")
      e4.play();
      console.log("after play")
       this.col4 = color (42, 2, 162);
    }
    else{
      this.col4 = color(0)
}

let p = dist(mouseX, mouseY, 475, 35)
    if(p < 12){
      
      console.log("before play")
      f4.play();
      console.log("after play")
      this.c4 = color (82, 2, 162);
    }
    else{
      this.c4 = color(0)

    }
    
  
}
    
    



